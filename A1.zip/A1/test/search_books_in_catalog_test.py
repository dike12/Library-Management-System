import pytest
import sys
sys.path.insert(0, '../')

from database import init_database
init_database()


from library_service import search_books_in_catalog

class TestSearchBooksValidation:
    """Test search parameter validation"""
    
    def test_search_empty_search_term(self):
        """
        Test: Empty search term
        Expected: Should return empty list or all books
        """
        result = search_books_in_catalog("", "title")
        
        assert isinstance(result, list)
        # Could return empty list or all books - both are valid approaches
    
    def test_search_none_search_term(self):
        """
        Test: None search term
        Expected: Should handle gracefully
        """
        result = search_books_in_catalog(None, "title")
        
        assert isinstance(result, list)
        # Should not crash, return empty list
    
    def test_search_whitespace_only_search_term(self):
        """
        Test: Search term with only whitespace
        Expected: Should handle gracefully, likely return empty results
        """
        result = search_books_in_catalog("   ", "title")
        
        assert isinstance(result, list)
    
    def test_search_invalid_search_type(self):
        """
        Test: Invalid search type
        Expected: Should default to title search or return empty
        """
        result = search_books_in_catalog("test", "invalid_type")
        
        assert isinstance(result, list)
    
    def test_search_none_search_type(self):
        """
        Test: None search type
        Expected: Should default to title search
        """
        result = search_books_in_catalog("test", None)
        
        assert isinstance(result, list)
    
    def test_search_case_insensitive_search_type(self):
        """
        Test: Search type with different cases
        Expected: Should accept TITLE, Title, title, etc.
        """
        result = search_books_in_catalog("gatsby", "TITLE")
        
        assert isinstance(result, list)

class TestSearchBooksByTitle:
    """Test title search functionality"""
    
    def test_search_exact_title_match(self):
        """
        Test: Exact title match for "The Great Gatsby"
        Expected: Should return exactly one matching book
        """
        result = search_books_in_catalog("The Great Gatsby", "title")
        
        assert len(result) == 1
        assert result[0]['title'] == "The Great Gatsby"
        assert result[0]['author'] == "F. Scott Fitzgerald"
    
    def test_search_partial_title_match(self):
        """
        Test: Partial title match (case-insensitive) for "gatsby"
        Expected: Should return "The Great Gatsby"
        """
        result = search_books_in_catalog("gatsby", "title")
        
        assert len(result) == 1
        assert "gatsby" in result[0]['title'].lower()
        assert result[0]['title'] == "The Great Gatsby"
    
    def test_search_title_case_insensitive(self):
        """
        Test: Case insensitive title search for "GREAT GATSBY"
        Expected: Should find "The Great Gatsby"
        """
        result = search_books_in_catalog("GREAT GATSBY", "title")
        
        assert len(result) == 1
        assert result[0]['title'] == "The Great Gatsby"
    
    def test_search_numeric_title(self):
        """
        Test: Search for numeric title "1984"
        Expected: Should return the book "1984" by George Orwell
        """
        result = search_books_in_catalog("1984", "title")
        
        assert len(result) == 1
        assert result[0]['title'] == "1984"
        assert result[0]['author'] == "George Orwell"
    
    def test_search_title_with_partial_word(self):
        """
        Test: Search for "Kill" should find "To Kill a Mockingbird"
        Expected: Should return matching book
        """
        result = search_books_in_catalog("Kill", "title")
        
        assert len(result) == 1
        assert result[0]['title'] == "To Kill a Mockingbird"
        assert result[0]['author'] == "Harper Lee"
    
    def test_search_nonexistent_title(self):
        """
        Test: Search for title that doesn't exist
        Expected: Should return empty list
        """
        result = search_books_in_catalog("Nonexistent Book Title XYZ", "title")
        
        assert len(result) == 0

class TestSearchBooksByAuthor:
    """Test author search functionality"""
    
    def test_search_exact_author_name(self):
        """
        Test: Exact author name "George Orwell"
        Expected: Should return "1984"
        """
        result = search_books_in_catalog("George Orwell", "author")
        
        assert len(result) == 1
        assert result[0]['author'] == "George Orwell"
        assert result[0]['title'] == "1984"
    
    def test_search_partial_author_last_name(self):
        """
        Test: Partial author search "Orwell"
        Expected: Should return book by George Orwell
        """
        result = search_books_in_catalog("Orwell", "author")
        
        assert len(result) == 1
        assert "orwell" in result[0]['author'].lower()
        assert result[0]['title'] == "1984"
    
    def test_search_partial_author_first_name(self):
        """
        Test: Search by first name "Harper"
        Expected: Should return book by Harper Lee
        """
        result = search_books_in_catalog("Harper", "author")
        
        assert len(result) == 1
        assert "Harper" in result[0]['author']
        assert result[0]['title'] == "To Kill a Mockingbird"
    
    def test_search_author_case_insensitive(self):
        """
        Test: Case insensitive author search "f. scott fitzgerald"
        Expected: Should find "The Great Gatsby"
        """
        result = search_books_in_catalog("f. scott fitzgerald", "author")
        
        assert len(result) == 1
        assert result[0]['author'] == "F. Scott Fitzgerald"
        assert result[0]['title'] == "The Great Gatsby"
    
    def test_search_nonexistent_author(self):
        """
        Test: Search for author that doesn't exist
        Expected: Should return empty list
        """
        result = search_books_in_catalog("Nonexistent Author XYZ", "author")
        
        assert len(result) == 0

class TestSearchBooksByISBN:
    """Test ISBN search functionality"""
    
    def test_search_exact_isbn_gatsby(self):
        """
        Test: Exact ISBN search for "The Great Gatsby"
        Expected: Should return exactly one book
        """
        result = search_books_in_catalog("9780743273565", "isbn")
        
        assert len(result) == 1
        assert result[0]['isbn'] == "9780743273565"
        assert result[0]['title'] == "The Great Gatsby"
    
    def test_search_exact_isbn_mockingbird(self):
        """
        Test: Exact ISBN search for "To Kill a Mockingbird"
        Expected: Should return exactly one book
        """
        result = search_books_in_catalog("9780061120084", "isbn")
        
        assert len(result) == 1
        assert result[0]['isbn'] == "9780061120084"
        assert result[0]['title'] == "To Kill a Mockingbird"
    
    def test_search_partial_isbn(self):
        """
        Test: Partial ISBN search "978074327"
        Expected: Should find "The Great Gatsby" (ISBN starts with this)
        """
        result = search_books_in_catalog("978074327", "isbn")
        
        assert len(result) == 1
        assert "978074327" in result[0]['isbn']
        assert result[0]['title'] == "The Great Gatsby"
    
    def test_search_nonexistent_isbn(self):
        """
        Test: Search for ISBN that doesn't exist
        Expected: Should return empty list
        """
        result = search_books_in_catalog("9999999999999", "isbn")
        
        assert len(result) == 0
