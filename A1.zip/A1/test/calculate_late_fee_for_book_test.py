import pytest
import sys
sys.path.insert(0, '../')

from database import init_database
init_database()


from library_service import calculate_late_fee_for_book

class TestLateFeeValidation:
    """Test patron ID and book ID validation"""
    
    def test_late_fee_empty_patron_id(self):
        """
        Test: Empty patron ID
        Expected: Should fail with validation error
        """
        result = calculate_late_fee_for_book("", 1)
        
        assert result['status'] == 'error'
        assert 'invalid patron id' in result.get('message', '').lower()
    
    def test_late_fee_invalid_patron_id_length(self):
        """
        Test: Invalid patron ID length
        Expected: Should fail with validation error
        """
        result = calculate_late_fee_for_book("12345", 1)  # Too short
        
        assert result['status'] == 'error'
        assert ('6 digits' in result.get('message', '').lower() or 
                'invalid patron id' in result.get('message', '').lower())
    
    def test_late_fee_patron_id_with_letters(self):
        """
        Test: Patron ID with non-digit characters
        Expected: Should fail with validation error
        """
        result = calculate_late_fee_for_book("12345A", 1)
        
        assert result['status'] == 'error'
        assert ('6 digits' in result.get('message', '').lower() or
                'invalid patron id' in result.get('message', '').lower())
    
    def test_late_fee_none_patron_id(self):
        """
        Test: None patron ID
        Expected: Should fail with validation error
        """
        result = calculate_late_fee_for_book(None, 1)
        
        assert result['status'] == 'error'
        assert ('invalid patron id' in result.get('message', '').lower() or
                'patron id is required' in result.get('message', '').lower())
    
    def test_late_fee_negative_book_id(self):
        """
        Test: Negative book ID
        Expected: Should fail with validation error
        """
        result = calculate_late_fee_for_book("123456", -1)
        
        assert result['status'] == 'error'
        assert ('book not found' in result.get('message', '').lower() or
                'invalid book id' in result.get('message', '').lower())
    
    def test_late_fee_zero_book_id(self):
        """
        Test: Zero book ID
        Expected: Should fail with validation error
        """
        result = calculate_late_fee_for_book("123456", 0)
        
        assert result['status'] == 'error'
        assert ('book not found' in result.get('message', '').lower() or
                'invalid book id' in result.get('message', '').lower())