import pytest
import sys
sys.path.insert(0, '../')

from database import init_database
init_database()


from library_service import borrow_book_by_patron
from datetime import datetime, timedelta


class TestBorrowBookByPatron:
    """Test suite for R3: Book Borrowing functionality"""
    
    def test_borrow_book_valid_request(self):
        """
        Positive test: Valid patron borrows available book
        Expected: Success with due date message
        """
        # Use a book that should be available (book_id=1 from sample data)
        success, message = borrow_book_by_patron("123456", 1)
        
        assert success == True
        assert "successfully borrowed" in message.lower()
        assert "due date:" in message.lower()
        # Check due date format (should be 14 days from now)
        assert datetime.now().strftime("%Y-%m") in message
    
    def test_borrow_book_different_valid_patron(self):
        """
        Positive test: Different valid patron borrows book
        Expected: Success
        """
        success, message = borrow_book_by_patron("654321", 2)
        
        assert success == True
        assert "successfully borrowed" in message.lower()
    
    # Patron ID Validation Tests
    def test_borrow_book_empty_patron_id(self):
        """
        Negative test: Empty patron ID
        Expected: Failure with validation error
        """
        success, message = borrow_book_by_patron("", 1)
        
        assert success == False
        assert "invalid patron id" in message.lower()
        assert "6 digits" in message
    
    def test_borrow_book_none_patron_id(self):
        """
        Negative test: None patron ID
        Expected: Failure with validation error
        """
        success, message = borrow_book_by_patron(None, 1)
        
        assert success == False
        assert "invalid patron id" in message.lower()
    
    def test_borrow_book_patron_id_too_short(self):
        """
        Negative test: Patron ID less than 6 digits
        Expected: Failure with validation error
        """
        success, message = borrow_book_by_patron("12345", 1)
        
        assert success == False
        assert "invalid patron id" in message.lower()
        assert "6 digits" in message
    
    def test_borrow_book_patron_id_too_long(self):
        """
        Negative test: Patron ID more than 6 digits
        Expected: Failure with validation error
        """
        success, message = borrow_book_by_patron("1234567", 1)
        
        assert success == False
        assert "invalid patron id" in message.lower()
        assert "6 digits" in message
    
    def test_borrow_book_patron_id_with_letters(self):
        """
        Negative test: Patron ID containing non-digit characters
        Expected: Failure with validation error
        """
        success, message = borrow_book_by_patron("12345A", 1)
        
        assert success == False
        assert "invalid patron id" in message.lower()
        assert "6 digits" in message
    
    def test_borrow_book_patron_id_with_spaces(self):
        """
        Negative test: Patron ID with spaces
        Expected: Failure with validation error
        """
        success, message = borrow_book_by_patron("12 34 56", 1)
        
        assert success == False
        assert "invalid patron id" in message.lower()
    
    # Book Validation Tests
    def test_borrow_nonexistent_book(self):
        """
        Negative test: Try to borrow book that doesn't exist
        Expected: Failure with book not found error
        """
        success, message = borrow_book_by_patron("123456", 99999)
        
        assert success == False
        assert "book not found" in message.lower()
    
    def test_borrow_unavailable_book(self):
        """
        Negative test: Try to borrow book with 0 available copies
        Expected: Failure with availability error
        """
        # Book ID 3 should be unavailable from sample data
        success, message = borrow_book_by_patron("123456", 3)
        
        assert success == False
        assert "not available" in message.lower()
    
    def test_borrow_book_negative_book_id(self):
        """
        Negative test: Negative book ID
        Expected: Failure with book not found
        """
        success, message = borrow_book_by_patron("123456", -1)
        
        assert success == False
        assert "book not found" in message.lower()
    
    def test_borrow_book_zero_book_id(self):
        """
        Negative test: Zero book ID
        Expected: Failure with book not found
        """
        success, message = borrow_book_by_patron("123456", 0)
        
        assert success == False
        assert "book not found" in message.lower()