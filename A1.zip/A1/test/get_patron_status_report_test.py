import pytest
import sys
sys.path.insert(0, '../')

from database import init_database
init_database()


from library_service import get_patron_status_report

class TestPatronStatusReport:
    """Test suite for R7: Patron Status Report functionality"""
    
    def test_patron_status_empty_patron_id(self):
        """
        Test: Empty patron ID
        Expected: Should return error status
        """
        result = get_patron_status_report("")
        
        assert isinstance(result, dict)
        assert result.get('status') == 'error'
        assert 'invalid patron id' in result.get('message', '').lower()
    
    def test_patron_status_invalid_patron_id_length(self):
        """
        Test: Invalid patron ID length
        Expected: Should return error for non-6-digit patron ID
        """
        result = get_patron_status_report("12345")  # Too short
        assert isinstance(result, dict)
        assert result.get('status') == 'error'
        assert ('6 digits' in result.get('message', '').lower() or
                'invalid patron id' in result.get('message', '').lower())
    
    def test_patron_status_valid_patron_with_books(self):
        """
        Test: Valid patron ID with borrowed books
        Expected: Should return complete status report
        """
        # Use patron "123456" who should have borrowed book ID 3 from sample data
        result = get_patron_status_report("123456")
        
        assert isinstance(result, dict)
        assert result.get('status') == 'success'
        assert 'patron_id' in result
        assert result['patron_id'] == "123456"
        
        # Should contain required R7 fields
        assert 'currently_borrowed_books' in result
        assert 'total_late_fees_owed' in result
        assert 'number_of_books_borrowed' in result
        assert 'borrowing_history' in result
    
    def test_patron_status_valid_patron_no_books(self):
        """
        Test: Valid patron ID with no borrowed books
        Expected: Should return status report with zero values
        """
        result = get_patron_status_report("999999")  # Patron with no borrows
        
        assert isinstance(result, dict)
        assert result.get('status') == 'success'
        assert result.get('number_of_books_borrowed') == 0
        assert result.get('total_late_fees_owed') == 0.0
        assert len(result.get('currently_borrowed_books', [])) == 0
    
    def test_patron_status_currently_borrowed_structure(self):
        """
        Test: Currently borrowed books data structure
        Expected: Should contain books with due dates
        """
        result = get_patron_status_report("123456")
        
        if result.get('status') == 'success':
            borrowed_books = result.get('currently_borrowed_books', [])
            
            if len(borrowed_books) > 0:
                book = borrowed_books[0]
                assert isinstance(book, dict)
                
                # Should contain required book information
                required_fields = ['book_id', 'title', 'author', 'due_date']
                for field in required_fields:
                    assert field in book, f"Book should contain '{field}' field"
    
    def test_patron_status_total_late_fees(self):
        """
        Test: Total late fees owed calculation
        Expected: Should calculate sum of all late fees
        """
        result = get_patron_status_report("123456")
        
        if result.get('status') == 'success':
            late_fees = result.get('total_late_fees_owed')
            assert isinstance(late_fees, (int, float))
            assert late_fees >= 0, "Late fees should be non-negative"
    
    def test_patron_status_borrowing_history_structure(self):
        """
        Test: Borrowing history data structure
        Expected: Should contain all patron's borrowing records
        """
        result = get_patron_status_report("123456")
        
        if result.get('status') == 'success':
            history = result.get('borrowing_history', [])
            assert isinstance(history, list)
            
            if len(history) > 0:
                record = history[0]
                assert isinstance(record, dict)
                
                # Should contain borrowing record information
                expected_fields = ['book_id', 'title', 'author', 'borrow_date']
                for field in expected_fields:
                    assert field in record, f"History record should contain '{field}'"
    
    def test_patron_status_all_required_fields(self):
        """
        Test: Response contains all R7 required fields
        Expected: Should include all specified information
        """
        result = get_patron_status_report("123456")
        
        if result.get('status') == 'success':
            # R7 requirements
            required_fields = [
                'currently_borrowed_books',    # Currently borrowed books with due dates
                'total_late_fees_owed',        # Total late fees owed
                'number_of_books_borrowed',    # Number of books currently borrowed
                'borrowing_history'            # Borrowing history
            ]
            
            for field in required_fields:
                assert field in result, f"Status report must contain '{field}' field"
    
    def test_patron_status_response_format(self):
        """
        Test: Response is properly formatted dictionary
        Expected: Should be JSON-serializable for display
        """
        result = get_patron_status_report("123456")
        
        assert isinstance(result, dict)
        
        # Test JSON serializability
        import json
        try:
            json_str = json.dumps(result, default=str)  # default=str handles datetime
            parsed = json.loads(json_str)
            assert isinstance(parsed, dict)
        except (TypeError, ValueError) as e:
            pytest.fail(f"Result should be JSON serializable: {e}")
    
    def test_patron_status_invalid_parameter_types(self):
        """
        Test: Handle invalid parameter types
        Expected: Should handle gracefully
        """
        result = get_patron_status_report(123456)  # Integer instead of string
        
        assert isinstance(result, dict)
        assert result.get('status') == 'error'