import pytest
import sys
sys.path.insert(0, '../')

from database import init_database
init_database()


from library_service import return_book_by_patron

class TestReturnBookValidation:
    """Test patron ID and book ID validation requirements"""
    
    def test_return_book_valid_patron_id_format(self):
        """
        Test: Valid 6-digit patron ID format
        Expected: Should succeed if patron has borrowed this book
        """
        success, message = return_book_by_patron("123456", 1)
        
        # Should not fail due to patron ID validation
        assert "invalid patron id" not in message.lower()
    
    def test_return_book_empty_patron_id(self):
        """
        Test: Empty patron ID
        Expected: Should fail with validation error
        """
        success, message = return_book_by_patron("", 1)
        
        assert success == False
        assert "invalid patron id" in message.lower() or "patron id is required" in message.lower()
    
    def test_return_book_invalid_patron_id_length(self):
        """
        Test: Invalid patron ID length
        Expected: Should fail with validation error
        """
        success, message = return_book_by_patron("12345", 1)  # Too short
        
        assert success == False
        assert "6 digits" in message or "invalid patron id" in message.lower()
    
    def test_return_book_patron_id_with_letters(self):
        """
        Test: Patron ID with non-digit characters
        Expected: Should fail with validation error
        """
        success, message = return_book_by_patron("12345A", 1)
        
        assert success == False
        assert "6 digits" in message or "invalid patron id" in message.lower()
    
    def test_return_book_none_patron_id(self):
        """
        Test: None patron ID
        Expected: Should fail with validation error
        """
        success, message = return_book_by_patron(None, 1)
        
        assert success == False
        assert "invalid patron id" in message.lower() or "patron id is required" in message.lower()
    
    def test_return_book_negative_book_id(self):
        """
        Test: Negative book ID
        Expected: Should fail with validation error
        """
        success, message = return_book_by_patron("123456", -1)
        
        assert success == False
        assert "book not found" in message.lower() or "invalid book id" in message.lower()
    
    def test_return_book_zero_book_id(self):
        """
        Test: Zero book ID
        Expected: Should fail with validation error
        """
        success, message = return_book_by_patron("123456", 0)
        
        assert success == False
        assert "book not found" in message.lower() or "invalid book id" in message.lower()